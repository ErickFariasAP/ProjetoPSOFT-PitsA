package com.ufcg.psoft.commerce.service.pedido;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ufcg.psoft.commerce.exception.pedido.PedidoInexistenteException;
import com.ufcg.psoft.commerce.exception.pedido.PedidoJaProntoException;
import com.ufcg.psoft.commerce.exception.CodigoInvalidoException;
import com.ufcg.psoft.commerce.exception.cliente.ClienteInexistenteException;
import com.ufcg.psoft.commerce.exception.estabelecimento.EstabelecimentoInexistenteException;
import com.ufcg.psoft.commerce.model.cliente.Cliente;
import com.ufcg.psoft.commerce.model.estabelecimento.Estabelecimento;
import com.ufcg.psoft.commerce.model.pedido.Pedido;
import com.ufcg.psoft.commerce.repository.cliente.ClienteRepository;
import com.ufcg.psoft.commerce.repository.estabelecimento.EstabelecimentoRepository;
import com.ufcg.psoft.commerce.repository.pedido.PedidoRepository;



@Service
public class PedidoDeleteV1Service implements PedidoDeleteService{
    @Autowired
    PedidoRepository pedidoRepository;

    @Autowired
    ClienteRepository clienteRepository;

    @Autowired
    EstabelecimentoRepository estabelecimentoRepository;

    @Override
    public void deleteCli(Long pedidoId, Long cliId, String codigoAcesso){
        if (cliId == null || !clienteRepository.existsById(cliId)) {
            throw new ClienteInexistenteException();
        }
        if(pedidoId == null || !pedidoRepository.existsById(pedidoId)) {
            throw new PedidoInexistenteException();
        }
        Cliente cliente = clienteRepository.findById(cliId).get();
        Pedido pedido = pedidoRepository.findById(pedidoId).get();
        if (pedido.getClienteId() != cliId || !codigoAcesso.equals(cliente.getCodigoAcesso())) {
            throw new CodigoInvalidoException();
        }
        pedidoRepository.delete(pedido);
    }

    @Override
    public void deleteEst(Long pedidoId, Long estId, String codigoAcesso) {
        if (estId == null || !estabelecimentoRepository.existsById(estId)) {
            throw new EstabelecimentoInexistenteException();
        }
        if(pedidoId == null || !pedidoRepository.existsById(pedidoId)) {
            throw new PedidoInexistenteException();
        }
        Estabelecimento est = estabelecimentoRepository.findById(estId).get();
        Pedido pedido = pedidoRepository.findById(pedidoId).get();
        if (pedido.getEstabelecimentoId() != estId || !codigoAcesso.equals(est.getCodigoAcesso())) {
            throw new CodigoInvalidoException();
        }
        pedidoRepository.delete(pedido);
    }

    @Override
    public void cliCancelaPedido(Long pedidoId, String codigoAcesso) {
        if(pedidoId == null || !pedidoRepository.existsById(pedidoId)) {
            throw new PedidoInexistenteException();
        }
        Pedido pedido = pedidoRepository.findById(pedidoId).get();
        Cliente cliente = clienteRepository.findById(pedido.getClienteId()).get();
        if (!codigoAcesso.equals(cliente.getCodigoAcesso())) {
                throw new CodigoInvalidoException();
        }
        if (pedido.getStatusEntrega() == "Pedido Pronto") {
            throw new PedidoJaProntoException();
        }
        pedidoRepository.delete(pedido);
    }

    @Override
    public void deleteAllCliente(Long cliId) {
        if (cliId == null || !clienteRepository.existsById(cliId)) {
            throw new ClienteInexistenteException();
        }
        for (Pedido pedido : pedidoRepository.findAll()) {
            if (pedido.getClienteId().equals(cliId)) {
                pedidoRepository.delete(pedido);
            }
        }
    }

    @Override
    public void deleteAllEst(Long estId) {
        if (estId == null || !estabelecimentoRepository.existsById(estId)) {
            throw new EstabelecimentoInexistenteException();
        }
        for (Pedido pedido : pedidoRepository.findAll()) {
            if (pedido.getEstabelecimentoId().equals(estId)) {
                pedidoRepository.delete(pedido);
            }
        }
    }
}

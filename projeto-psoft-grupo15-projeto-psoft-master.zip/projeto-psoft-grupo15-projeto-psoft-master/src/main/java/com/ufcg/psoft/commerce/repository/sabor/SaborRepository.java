package com.ufcg.psoft.commerce.repository.sabor;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ufcg.psoft.commerce.model.sabor.Sabor;

public interface SaborRepository extends JpaRepository<Sabor, Long> {

}

package com.ufcg.psoft.commerce.service.pedido;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ufcg.psoft.commerce.exception.CodigoInvalidoException;
import com.ufcg.psoft.commerce.exception.pedido.PedidoInexistenteException;
import com.ufcg.psoft.commerce.model.cliente.Cliente;
import com.ufcg.psoft.commerce.model.entregador.Entregador;
import com.ufcg.psoft.commerce.model.estabelecimento.Estabelecimento;
import com.ufcg.psoft.commerce.model.pedido.Pedido;
import com.ufcg.psoft.commerce.repository.cliente.ClienteRepository;
import com.ufcg.psoft.commerce.repository.entregador.EntregadorRepository;
import com.ufcg.psoft.commerce.repository.estabelecimento.EstabelecimentoRepository;
import com.ufcg.psoft.commerce.repository.pedido.PedidoRepository;

@Service
public class PedidoEncaminhaV1Service implements PedidoEncaminhaService {
    @Autowired
    private EstabelecimentoRepository estabelecimentoRepository;

    @Autowired
    private PedidoRepository pedidoRepository;

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private EntregadorRepository entregadorRepository;

    @Override
    public Pedido encaminhaPedido(Long id, String estCodAcesso) {
        Pedido pedido = pedidoRepository.findById(id).orElseThrow(PedidoInexistenteException::new);
        Cliente pedidoCliente = clienteRepository.findById(pedido.getClienteId()).get();
        Entregador pedidoEntregador = entregadorRepository.findById(pedido.getEntregadorId()).get();
        Estabelecimento pedidoEstabelecimento = estabelecimentoRepository.findById(pedido.getEstabelecimentoId()).get();
        if (!pedidoEstabelecimento.getCodigoAcesso().equals(estCodAcesso)) {
            throw new CodigoInvalidoException();
        }
        //pedido.setStatusEntrega("Pedido em rota");

        
        String notif = "PEDIDO #" + pedido.getId() + " A CAMINHO";
        notif += "\n Cliente: " + pedidoCliente.getId() + " - " + pedidoCliente.getNome();
        notif += "\n Entregador: " + pedidoEntregador.getNome();
        notif += "\n Veículo do Entregador: " + pedidoEntregador.getTipoVeiculo() + 
                " - " + pedidoEntregador.getCorVeiculo() +
                " - " + pedidoEntregador.getPlacaVeiculo();

        System.out.println(notif);

        return pedido;
    }
}

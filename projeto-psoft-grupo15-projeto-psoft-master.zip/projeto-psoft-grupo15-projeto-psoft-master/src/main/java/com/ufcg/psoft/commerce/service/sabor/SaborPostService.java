package com.ufcg.psoft.commerce.service.sabor;

import com.ufcg.psoft.commerce.dto.sabor.SaborPostPutDTO;
import com.ufcg.psoft.commerce.model.sabor.Sabor;

@FunctionalInterface
public interface SaborPostService {

    public Sabor post(Long estId, String codEst, SaborPostPutDTO saborPostPutDTO);
    
}

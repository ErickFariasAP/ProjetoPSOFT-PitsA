package com.ufcg.psoft.commerce.service.pedido;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ufcg.psoft.commerce.exception.pedido.PedidoInexistenteException;
import com.ufcg.psoft.commerce.exception.pedido.PedidoNaoEntregueException;
import com.ufcg.psoft.commerce.model.estabelecimento.Estabelecimento;
import com.ufcg.psoft.commerce.model.pedido.Pedido;
import com.ufcg.psoft.commerce.repository.estabelecimento.EstabelecimentoRepository;
import com.ufcg.psoft.commerce.repository.pedido.PedidoRepository;

@Service
public class PedidoEntregueEstabelecimentoV1Service implements PedidoEntregueEstabelecimentoService {
    @Autowired
    EstabelecimentoRepository estabelecimentoRepository;
    @Autowired
    PedidoRepository pedidoRepository;

    @Override
    public Pedido notificaEntregaEstabelecimento(Long pedidoId) {
        Pedido pedido = pedidoRepository.findById(pedidoId).orElseThrow(PedidoInexistenteException::new);
        if (pedido.getStatusEntrega() != "Pedido entregue") {
            throw new PedidoNaoEntregueException();
        }
        Estabelecimento estabelecimento = estabelecimentoRepository.findById(pedido.getEstabelecimentoId()).get();
        String notif = "PEDIDO #" + pedido.getId() + " ENTREGUE";
        notif += "\n Estabelecimento: " + estabelecimento.getId() + " - " + estabelecimento.getNome();
        System.out.println(notif);
        
        return pedido;
    }
}

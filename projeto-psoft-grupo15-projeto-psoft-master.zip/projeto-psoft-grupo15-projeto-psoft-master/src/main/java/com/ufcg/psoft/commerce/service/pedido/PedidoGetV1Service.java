package com.ufcg.psoft.commerce.service.pedido;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ufcg.psoft.commerce.dto.pedido.PedidoResponseDTO;
import com.ufcg.psoft.commerce.exception.CodigoInvalidoException;
import com.ufcg.psoft.commerce.exception.cliente.ClienteInexistenteException;
import com.ufcg.psoft.commerce.exception.estabelecimento.EstabelecimentoInexistenteException;
import com.ufcg.psoft.commerce.exception.pedido.PedidoInexistenteException;
import com.ufcg.psoft.commerce.model.cliente.Cliente;
import com.ufcg.psoft.commerce.model.estabelecimento.Estabelecimento;
import com.ufcg.psoft.commerce.model.pedido.Pedido;
import com.ufcg.psoft.commerce.repository.cliente.ClienteRepository;
import com.ufcg.psoft.commerce.repository.estabelecimento.EstabelecimentoRepository;
import com.ufcg.psoft.commerce.repository.pedido.PedidoRepository;

@Service
public class PedidoGetV1Service implements PedidoGetService{
    @Autowired
    PedidoRepository pedidoRepository;

    @Autowired
    ModelMapper modelMapper;

    @Autowired
    ClienteRepository clienteRepository;

    @Autowired
    EstabelecimentoRepository estabelecimentoRepository;

    @Override
    public PedidoResponseDTO get(Long id) {
        if (!pedidoRepository.existsById(id)) {
            throw new PedidoInexistenteException();
        }
        PedidoResponseDTO pedidoGetRequestDTO = modelMapper.map(pedidoRepository.findById(id), PedidoResponseDTO.class);
        return pedidoGetRequestDTO;
    }

    @Override
    public List<PedidoResponseDTO> getAll(Long cliId, Long estId) {
        List<Pedido> todosPedidos = pedidoRepository.findAll();
        Collections.reverse(todosPedidos); // mais recentes primeiro
        if (cliId != null) {
            if (!clienteRepository.existsById(cliId)) {
                throw new ClienteInexistenteException();
            }
            todosPedidos = todosPedidos.stream()
                    .filter(pedido -> pedido.getClienteId().equals(cliId))
                    .collect(Collectors.toList());
        }
        if (estId != null) {
            if (!estabelecimentoRepository.existsById(estId)) {
                throw new EstabelecimentoInexistenteException();
            }
            todosPedidos = todosPedidos.stream()
                    .filter(pedido -> pedido.getEstabelecimentoId().equals(estId))
                    .collect(Collectors.toList());
        }

        // separa entregues dos não entregues. não entregues vêm antes
        List<Pedido> todosPedidosNaoEntregues = todosPedidos.stream()
                .filter(pedido -> pedido.getStatusEntrega() != null && !pedido.getStatusEntrega().equals("Pedido entregue"))
                .collect(Collectors.toList());
        
        List<Pedido> todosPedidosEntregues = todosPedidos.stream()
                .filter(pedido -> pedido.getStatusEntrega() == null || pedido.getStatusEntrega().equals("Pedido entregue"))
                .collect(Collectors.toList());
        
        todosPedidos = todosPedidosNaoEntregues;
        todosPedidos.addAll(todosPedidosEntregues);

        return todosPedidos.stream()
                .map(pedido -> modelMapper.map(pedido, PedidoResponseDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<PedidoResponseDTO> getAllFromClient(Long cliId, Long estabId, String cliCodigoAcesso) {
        Cliente cliente = clienteRepository.findById(cliId).orElseThrow(ClienteInexistenteException::new);
        if (!cliente.getCodigoAcesso().equals(cliCodigoAcesso)) {
            throw new CodigoInvalidoException();
        }
        return getAll(cliId, estabId);
    }

    @Override
    public List<PedidoResponseDTO> getAllWithStatus(Long cliId, Long estId, String statusEntrega, String cliCodigoAcesso){
        return getAllFromClient(cliId, estId, cliCodigoAcesso).stream()
                .filter(pedido -> pedido.getStatusEntrega() != null && pedido.getStatusEntrega().equals(statusEntrega))
                .collect(Collectors.toList());
    }

    @Override
    public PedidoResponseDTO getFromClient(Long id, Long clienteId) {
        if (!clienteRepository.existsById(clienteId)) {
            throw new ClienteInexistenteException();
        }

        if (!pedidoRepository.existsById(id)) {
            throw new PedidoInexistenteException();
        }

        Pedido pedido = pedidoRepository.findById(id).get();

        if (!pedido.getClienteId().equals(clienteId)) {
            throw new CodigoInvalidoException();
        }

        return modelMapper.map(pedido, PedidoResponseDTO.class);
    }

    @Override
    public PedidoResponseDTO getFromEstabelecimento(Long id, Long estabelecimentoId, String codigoAcesso) {
        if (!estabelecimentoRepository.existsById(estabelecimentoId)) {
            throw new EstabelecimentoInexistenteException();
        }
        if (!pedidoRepository.existsById(id)) {
            throw new PedidoInexistenteException();
        }

        Pedido pedido = pedidoRepository.findById(id).get();
        Estabelecimento estabelecimento = estabelecimentoRepository.findById(estabelecimentoId).get();
        Estabelecimento pedidoEstabelecimento = estabelecimentoRepository.findById(pedido.getEstabelecimentoId()).get();

        if (!estabelecimento.equals(pedidoEstabelecimento)) {
            throw new CodigoInvalidoException();
        }

        if (!pedidoEstabelecimento.getCodigoAcesso().equals(codigoAcesso)) {
            throw new CodigoInvalidoException();
        }

        return modelMapper.map(pedido, PedidoResponseDTO.class);
    }

    @Override
    public List<PedidoResponseDTO> getFromClienteAndEstabelecimento(Long id, Long clienteId, Long estId, String codigoAcesso) {
        
        if (!clienteRepository.existsById(clienteId)) {
            throw new ClienteInexistenteException();
        }
        if (!clienteRepository.findById(clienteId).get().getCodigoAcesso().equals(codigoAcesso)) {
            throw new CodigoInvalidoException();
        }
        
        if (id == null){
            return getAll(clienteId, estId);
        }
        if (!estabelecimentoRepository.existsById(estId)) {
            throw new EstabelecimentoInexistenteException();
        }
        if (!pedidoRepository.existsById(id)) {
            throw new PedidoInexistenteException();
        }

        Pedido pedido = pedidoRepository.findById(id).get();
        Estabelecimento estabelecimento = estabelecimentoRepository.findById(estId).get();
        Estabelecimento pedidoEstabelecimento = estabelecimentoRepository.findById(pedido.getEstabelecimentoId()).get();

        if (!estabelecimento.equals(pedidoEstabelecimento)) {
            throw new CodigoInvalidoException();
        }

        if (!pedido.getClienteId().equals(clienteId)) {
            throw new CodigoInvalidoException();
        }

        //convert to dto

        PedidoResponseDTO pedidoDTO = modelMapper.map(pedido, PedidoResponseDTO.class);

        //put as first of list

        List<PedidoResponseDTO> pedidos = new ArrayList<>();
        pedidos.add(pedidoDTO);
        return pedidos;
    }
}

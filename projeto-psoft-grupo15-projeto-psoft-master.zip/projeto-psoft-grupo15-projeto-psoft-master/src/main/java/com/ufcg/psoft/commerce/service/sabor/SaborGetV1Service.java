package com.ufcg.psoft.commerce.service.sabor;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.ufcg.psoft.commerce.exception.CodigoInvalidoException;
import com.ufcg.psoft.commerce.exception.estabelecimento.EstabelecimentoInexistenteException;
import com.ufcg.psoft.commerce.exception.sabor.SaborInexistenteException;
import com.ufcg.psoft.commerce.model.estabelecimento.Estabelecimento;
import com.ufcg.psoft.commerce.model.sabor.Sabor;
import com.ufcg.psoft.commerce.repository.estabelecimento.EstabelecimentoRepository;
import com.ufcg.psoft.commerce.repository.sabor.SaborRepository;
import org.springframework.stereotype.Service;

@Service
public class SaborGetV1Service implements SaborGetService {

    @Autowired
    SaborRepository repository;

    @Autowired
    EstabelecimentoRepository estRepository;

    @Override
    public List<Sabor> getAll(Long estId, String codEst) {

        Estabelecimento estabelecimento = estRepository.findById(estId)
                .orElseThrow(EstabelecimentoInexistenteException::new);

        if (!estabelecimento.getCodigoAcesso().equals(codEst)) {
            throw new CodigoInvalidoException();
        }

        return repository.findAll();
    }

    @Override
    public Sabor get(Long id, Long estId, String codEst) {

        Estabelecimento estabelecimento = estRepository.findById(estId)
                .orElseThrow(EstabelecimentoInexistenteException::new);

        if (!estabelecimento.getCodigoAcesso().equals(codEst)) {
            throw new CodigoInvalidoException();
        }

        return repository.findById(id).orElseThrow(SaborInexistenteException::new);  
    }

}

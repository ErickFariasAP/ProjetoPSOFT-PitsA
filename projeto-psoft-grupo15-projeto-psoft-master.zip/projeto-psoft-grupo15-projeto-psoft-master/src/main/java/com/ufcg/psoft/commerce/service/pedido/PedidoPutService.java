package com.ufcg.psoft.commerce.service.pedido;

import com.ufcg.psoft.commerce.dto.pedido.PedidoPostPutRequestDTO;
import com.ufcg.psoft.commerce.model.pedido.Pedido;

@FunctionalInterface
public interface PedidoPutService {
    public Pedido put(Long pedidoId, String cliCodAcesso, PedidoPostPutRequestDTO pedidoPostPutRequestDTO);
}

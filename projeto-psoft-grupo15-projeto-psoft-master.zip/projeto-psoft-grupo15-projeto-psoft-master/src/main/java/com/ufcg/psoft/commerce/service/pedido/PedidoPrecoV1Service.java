package com.ufcg.psoft.commerce.service.pedido;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ufcg.psoft.commerce.dto.pedido.PedidoPostPutRequestDTO;
import com.ufcg.psoft.commerce.exception.sabor.SaborInexistenteException;
import com.ufcg.psoft.commerce.model.pizza.Pizza;
import com.ufcg.psoft.commerce.model.sabor.Sabor;
import com.ufcg.psoft.commerce.repository.pedido.PedidoRepository;
import com.ufcg.psoft.commerce.repository.sabor.SaborRepository;

@Service
public class PedidoPrecoV1Service implements PedidoPrecoService {
    @Autowired
    ModelMapper modelMapper;

    @Autowired
    PedidoRepository pedidoRepository;

    @Autowired
    SaborRepository saborRepository;

    @Override
    public double calcPreco(PedidoPostPutRequestDTO pedido) {
        List<Pizza> pizzas = pedido.getPizzas();

        double total = 0;
        for (Pizza pizza : pizzas) {
            Sabor sabor1 = saborRepository.findById(pizza.getSabor1().getId())
                    .orElseThrow(SaborInexistenteException::new);

            if (pizza.getSabor2() != null) {
                Sabor sabor2 = saborRepository.findById(pizza.getSabor2().getId())
                                            .orElseThrow(SaborInexistenteException::new);

                total += ((sabor1.getPrecoG() / 2) + (sabor2.getPrecoG() / 2));
            } else if (pizza.getTamanho().equals("grande")) {
                total += (sabor1.getPrecoG());
            }
            else {
                total += sabor1.getPrecoM();
            }
        }
        return total;
    }
}

package com.ufcg.psoft.commerce.service.sabor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ufcg.psoft.commerce.exception.CodigoInvalidoException;
import com.ufcg.psoft.commerce.exception.estabelecimento.EstabelecimentoInexistenteException;
import com.ufcg.psoft.commerce.exception.sabor.SaborInexistenteException;
import com.ufcg.psoft.commerce.model.estabelecimento.Estabelecimento;
import com.ufcg.psoft.commerce.repository.estabelecimento.EstabelecimentoRepository;
import com.ufcg.psoft.commerce.repository.sabor.SaborRepository;

@Service
public class SaborDeleteV1Service implements SaborDeleteService {

    @Autowired
    SaborRepository saborRepository;

    @Autowired
    EstabelecimentoRepository estRepository;

    @Override
    public void delete(Long id, Long estId, String codEst) {

        Estabelecimento estabelecimento = estRepository.findById(estId)
                .orElseThrow(EstabelecimentoInexistenteException::new);

        if (!estabelecimento.getCodigoAcesso().equals(codEst)) {
            throw new CodigoInvalidoException();
        }

        saborRepository.findById(id).orElseThrow(SaborInexistenteException::new);
        saborRepository.deleteById(id);
    }

}

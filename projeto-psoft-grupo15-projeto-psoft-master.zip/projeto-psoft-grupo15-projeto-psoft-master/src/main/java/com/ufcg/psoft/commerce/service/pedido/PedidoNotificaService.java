package com.ufcg.psoft.commerce.service.pedido;

import com.ufcg.psoft.commerce.model.pedido.Pedido;

public interface PedidoNotificaService {
    public Pedido notificaPedido(Long id, String estCodAcesso, String statusPedido);
}

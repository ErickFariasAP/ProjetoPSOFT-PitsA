package com.ufcg.psoft.commerce.service.pedido;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ufcg.psoft.commerce.dto.pedido.PedidoPostPutRequestDTO;
import com.ufcg.psoft.commerce.exception.CodigoInvalidoException;
import com.ufcg.psoft.commerce.exception.CommerceException;
import com.ufcg.psoft.commerce.exception.cliente.ClienteInexistenteException;
import com.ufcg.psoft.commerce.exception.pedido.PedidoInexistenteException;
import com.ufcg.psoft.commerce.model.cliente.Cliente;
import com.ufcg.psoft.commerce.model.pedido.Pedido;
import com.ufcg.psoft.commerce.repository.cliente.ClienteRepository;
import com.ufcg.psoft.commerce.repository.pedido.PedidoRepository;

@Service
public class PedidoPutPagamentoV1Service implements PedidoPutPagamentoService {

    @Autowired
    PedidoRepository pedidoRepository;

    @Autowired
    ClienteRepository clienteRepository;
    
    @Autowired
    PedidoPrecoService pedidoPrecoService;

    @Autowired
    PedidoDescontoService pedidoDescontoService;

    @Autowired
    ModelMapper modelMapper;

    public Pedido putPagamento(Long cliId, String cliCodAcesso, Long pedidoId, String metodoPagamento, PedidoPostPutRequestDTO pedidoPostPutRequestDTO) {
        if (pedidoId == null || cliCodAcesso == null || cliId == null || metodoPagamento == null){
             throw new CommerceException();
        }

        Pedido pedido = pedidoRepository.findById(pedidoId).orElseThrow(PedidoInexistenteException::new);
        Cliente cliente = clienteRepository.findById(cliId).orElseThrow(ClienteInexistenteException::new);

        if (cliCodAcesso.equals(cliente.getCodigoAcesso())) {
            pedido.setPreco(pedidoDescontoService.calculaDesconto(pedidoPostPutRequestDTO, metodoPagamento));
            pedido.setMeioPagamento(metodoPagamento);
            pedido.setStatusPagamento(true);
            return pedido;
        } else {
        throw new CodigoInvalidoException();
        }
        //return null;
    }
}

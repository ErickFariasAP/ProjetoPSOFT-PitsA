package com.ufcg.psoft.commerce.service.sabor;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ufcg.psoft.commerce.exception.CodigoInvalidoException;
import com.ufcg.psoft.commerce.exception.estabelecimento.EstabelecimentoInexistenteException;
import com.ufcg.psoft.commerce.exception.sabor.SaborFalseException;
import com.ufcg.psoft.commerce.exception.sabor.SaborInexistenteException;
import com.ufcg.psoft.commerce.exception.sabor.SaborTrueException;
import com.ufcg.psoft.commerce.model.estabelecimento.Estabelecimento;
import com.ufcg.psoft.commerce.model.sabor.Sabor;
import com.ufcg.psoft.commerce.repository.estabelecimento.EstabelecimentoRepository;
import com.ufcg.psoft.commerce.repository.sabor.SaborRepository;
@Service
public class SaborDisponibilidadeV1Service  implements SaborDisponibilidadeService {
    @Autowired
    SaborRepository saborRepository;
    @Autowired
    EstabelecimentoRepository estRepository;
    @Autowired
    ModelMapper modelMapper;

    @Override
    public Sabor putDisponivel(Long id, Long estId, String codEst, Boolean disponibilidade) {
        Sabor sabor = saborRepository.findById(id).orElseThrow(SaborInexistenteException::new);

        Boolean saborDisp = sabor.getDisponibilidade();

        if (saborDisp.equals(disponibilidade)) {
            throw (disponibilidade) ? new SaborTrueException() : new SaborFalseException();
        }

        sabor.setDisponibilidade(disponibilidade);

        Estabelecimento estabelecimento = estRepository.findById(estId)
                .orElseThrow(EstabelecimentoInexistenteException::new);

        if (!estabelecimento.getCodigoAcesso().equals(codEst)) {
            throw new CodigoInvalidoException();
        }

        return saborRepository.save(sabor);
    }
    
}

package com.ufcg.psoft.commerce.repository.entregador;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ufcg.psoft.commerce.model.entregador.Entregador;

public interface EntregadorRepository extends JpaRepository<Entregador, Long> {
}

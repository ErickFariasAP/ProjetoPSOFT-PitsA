package com.ufcg.psoft.commerce.service.sabor;

import com.ufcg.psoft.commerce.model.sabor.Sabor;

@FunctionalInterface
public interface SaborDisponibilidadeService {

    public Sabor putDisponivel(Long id, Long estId, String codEst, Boolean disponibilidade);

    
}

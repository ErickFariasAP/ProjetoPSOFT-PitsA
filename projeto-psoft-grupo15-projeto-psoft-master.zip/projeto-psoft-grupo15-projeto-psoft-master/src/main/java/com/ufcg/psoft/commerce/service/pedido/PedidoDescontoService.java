package com.ufcg.psoft.commerce.service.pedido;

import com.ufcg.psoft.commerce.dto.pedido.PedidoPostPutRequestDTO;

@FunctionalInterface
public interface PedidoDescontoService {
    public double calculaDesconto(PedidoPostPutRequestDTO pedidoPostPutRequestDTO, String metodoPagamento);
}

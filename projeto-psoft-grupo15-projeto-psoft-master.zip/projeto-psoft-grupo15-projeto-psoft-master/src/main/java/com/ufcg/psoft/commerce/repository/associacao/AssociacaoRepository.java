package com.ufcg.psoft.commerce.repository.associacao;


import org.springframework.data.jpa.repository.JpaRepository;

import com.ufcg.psoft.commerce.model.associacao.Associacao;

public interface AssociacaoRepository extends JpaRepository<Associacao, Long>{

}
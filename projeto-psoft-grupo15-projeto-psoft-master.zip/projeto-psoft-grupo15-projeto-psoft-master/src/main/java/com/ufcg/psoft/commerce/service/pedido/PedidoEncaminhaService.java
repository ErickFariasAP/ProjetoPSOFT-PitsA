package com.ufcg.psoft.commerce.service.pedido;

import org.springframework.stereotype.Service;

import com.ufcg.psoft.commerce.model.pedido.Pedido;

@Service
public interface PedidoEncaminhaService {
    public Pedido encaminhaPedido(Long id, String estCodigoAcesso);
}

package com.ufcg.psoft.commerce.service.sabor;

@FunctionalInterface
public interface SaborDeleteService {

    public void delete(Long id, Long estId, String codEst);
    
}

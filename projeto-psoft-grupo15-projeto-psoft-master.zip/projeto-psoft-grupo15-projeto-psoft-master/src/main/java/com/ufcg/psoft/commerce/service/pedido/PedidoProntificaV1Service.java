package com.ufcg.psoft.commerce.service.pedido;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ufcg.psoft.commerce.exception.CodigoInvalidoException;
import com.ufcg.psoft.commerce.exception.pedido.PedidoInexistenteException;
import com.ufcg.psoft.commerce.exception.pedido.PedidoStatusException;
import com.ufcg.psoft.commerce.model.estabelecimento.Estabelecimento;
import com.ufcg.psoft.commerce.model.pedido.Pedido;
import com.ufcg.psoft.commerce.repository.estabelecimento.EstabelecimentoRepository;
import com.ufcg.psoft.commerce.repository.pedido.PedidoRepository;

@Service
public class PedidoProntificaV1Service implements PedidoProntificaService {

    @Autowired
    private EstabelecimentoRepository estabelecimentoRepository;

    @Autowired
    private PedidoRepository pedidoRepository;
    @Autowired
    PedidoNotificaService pedidoNotificaService;

    @Override
    public Pedido prontificaPedido(Long id, String estCodAcesso) {
        Pedido pedido = pedidoRepository.findById(id).orElseThrow(PedidoInexistenteException::new);
        Estabelecimento pedidoEstabelecimento = estabelecimentoRepository.findById(pedido.getEstabelecimentoId()).get();
        if (!pedidoEstabelecimento.getCodigoAcesso().equals(estCodAcesso)) {
            throw new CodigoInvalidoException();
        }
        if (!pedido.getStatusEntrega().equals("Pedido em preparo")) {
            throw new PedidoStatusException();
        }
        pedido.setStatusEntrega("Pedido pronto");
        pedidoNotificaService.notificaPedido(id, estCodAcesso, "Pedido pronto");
        return pedido;
    }
    
}

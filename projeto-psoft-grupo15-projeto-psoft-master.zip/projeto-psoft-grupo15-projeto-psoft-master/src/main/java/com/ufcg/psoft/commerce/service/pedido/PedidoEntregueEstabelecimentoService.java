package com.ufcg.psoft.commerce.service.pedido;

import com.ufcg.psoft.commerce.model.pedido.Pedido;

@FunctionalInterface
public interface PedidoEntregueEstabelecimentoService {

    public Pedido notificaEntregaEstabelecimento(Long pedidoId);
    
}

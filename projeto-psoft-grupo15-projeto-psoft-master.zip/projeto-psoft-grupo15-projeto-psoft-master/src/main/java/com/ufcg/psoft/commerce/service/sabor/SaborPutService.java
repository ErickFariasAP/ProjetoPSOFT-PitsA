package com.ufcg.psoft.commerce.service.sabor;

import com.ufcg.psoft.commerce.dto.sabor.SaborPostPutDTO;
import com.ufcg.psoft.commerce.model.sabor.Sabor;

@FunctionalInterface
public interface SaborPutService {

    public Sabor put(Long id, Long estId, String codEst, SaborPostPutDTO saborPostPutDTO);

}

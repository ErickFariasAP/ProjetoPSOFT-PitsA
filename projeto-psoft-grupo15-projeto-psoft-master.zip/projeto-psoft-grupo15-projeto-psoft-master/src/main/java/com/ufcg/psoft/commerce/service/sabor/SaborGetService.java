package com.ufcg.psoft.commerce.service.sabor;

import java.util.List;

import com.ufcg.psoft.commerce.model.sabor.Sabor;
import org.springframework.stereotype.Service;

@Service
public interface SaborGetService {

    public List<Sabor> getAll(Long estId, String codEst);

    public Sabor get(Long id, Long estId, String codEst);
    
}

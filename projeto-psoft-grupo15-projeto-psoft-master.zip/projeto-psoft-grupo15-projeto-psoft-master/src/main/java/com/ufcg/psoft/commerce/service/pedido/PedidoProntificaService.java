package com.ufcg.psoft.commerce.service.pedido;

import org.springframework.stereotype.Service;

import com.ufcg.psoft.commerce.model.pedido.Pedido;

@Service
public interface PedidoProntificaService {
    public Pedido prontificaPedido(Long id, String estCodigoAcesso);
}

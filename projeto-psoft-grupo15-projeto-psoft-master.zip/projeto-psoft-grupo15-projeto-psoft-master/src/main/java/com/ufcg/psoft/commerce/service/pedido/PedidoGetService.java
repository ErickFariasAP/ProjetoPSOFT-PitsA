package com.ufcg.psoft.commerce.service.pedido;


import java.util.List;

import org.springframework.stereotype.Service;

import com.ufcg.psoft.commerce.dto.pedido.PedidoResponseDTO;

@Service
public interface PedidoGetService {
    public PedidoResponseDTO get(Long id);
    
    public List<PedidoResponseDTO> getAll(Long clienteId, Long estId);

    public List<PedidoResponseDTO> getAllFromClient(Long cliId, Long estId, String cliCodigoAcesso);

    public List<PedidoResponseDTO> getAllWithStatus(Long cliId, Long estId, String statusEntrega, String cliCodigoAcesso);

    public PedidoResponseDTO getFromClient(Long id, Long clienteId);

    public PedidoResponseDTO getFromEstabelecimento(Long id, Long estabelecimentoId, String codigoAcesso);

    public List<PedidoResponseDTO> getFromClienteAndEstabelecimento(Long id, Long clienteId, Long estId, String codigoAcesso);

}

package com.ufcg.psoft.commerce.service.pedido;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ufcg.psoft.commerce.dto.pedido.PedidoPostPutRequestDTO;
import com.ufcg.psoft.commerce.exception.CodigoInvalidoException;
import com.ufcg.psoft.commerce.exception.cliente.ClienteInexistenteException;
import com.ufcg.psoft.commerce.exception.estabelecimento.EstabelecimentoInexistenteException;
import com.ufcg.psoft.commerce.model.cliente.Cliente;
import com.ufcg.psoft.commerce.model.pedido.Pedido;
import com.ufcg.psoft.commerce.repository.cliente.ClienteRepository;
import com.ufcg.psoft.commerce.repository.estabelecimento.EstabelecimentoRepository;
import com.ufcg.psoft.commerce.repository.pedido.PedidoRepository;
import com.ufcg.psoft.commerce.repository.sabor.SaborRepository;

@Service
public class PedidoPostV1Service implements PedidoPostService {
    @Autowired
    PedidoRepository pedidoRepository;

    @Autowired
    SaborRepository saborRepository;

    @Autowired
    ClienteRepository clienteRepository;

    @Autowired
    EstabelecimentoRepository estabelecimentoRepository;
    
    @Autowired
    PedidoPrecoService pedidoPrecoService;
    
    @Override
    public Pedido post(Long clienteId, String cliCodAcesso, Long estabelecimentoId, PedidoPostPutRequestDTO pedidoPostPutRequestDTO) {

        estabelecimentoRepository.findById(estabelecimentoId).orElseThrow(EstabelecimentoInexistenteException::new);
        Cliente cliente = clienteRepository.findById(clienteId).orElseThrow(ClienteInexistenteException::new);
        if (!cliente.getCodigoAcesso().equals(cliCodAcesso)) {
            throw new CodigoInvalidoException();
        }

        String endereco = pedidoPostPutRequestDTO.getEnderecoEntrega();
        if (endereco == null){
            endereco = cliente.getEndereco();
        }

        Double preco = pedidoPrecoService.calcPreco(pedidoPostPutRequestDTO);

        String meioPagamento = pedidoPostPutRequestDTO.getMeioPagamento();


        Pedido pedido = Pedido.builder()
                .preco(preco)
                .enderecoEntrega(endereco)
                .estabelecimentoId(estabelecimentoId)
                .clienteId(clienteId)
                .entregadorId(1L)
                .pizzas(pedidoPostPutRequestDTO.getPizzas())
                .statusEntrega("Pedido recebido")
                .meioPagamento(meioPagamento)
                .build();




        
        return this.pedidoRepository.save(pedido);
    }
}

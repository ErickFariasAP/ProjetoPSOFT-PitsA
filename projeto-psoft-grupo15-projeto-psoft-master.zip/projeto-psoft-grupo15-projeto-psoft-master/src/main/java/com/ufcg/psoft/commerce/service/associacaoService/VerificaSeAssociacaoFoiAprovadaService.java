package com.ufcg.psoft.commerce.service.associacaoService;

@FunctionalInterface
public interface VerificaSeAssociacaoFoiAprovadaService {
    public boolean verificaSeAssociacaoFoiAprovada(Long id);
}
package com.ufcg.psoft.commerce.service.pedido;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ufcg.psoft.commerce.dto.pedido.PedidoPostPutRequestDTO;
import com.ufcg.psoft.commerce.exception.CodigoInvalidoException;
import com.ufcg.psoft.commerce.exception.CommerceException;
import com.ufcg.psoft.commerce.exception.cliente.ClienteInexistenteException;
import com.ufcg.psoft.commerce.exception.pedido.PedidoInexistenteException;
import com.ufcg.psoft.commerce.model.cliente.Cliente;
import com.ufcg.psoft.commerce.model.pedido.Pedido;
import com.ufcg.psoft.commerce.repository.cliente.ClienteRepository;
import com.ufcg.psoft.commerce.repository.pedido.PedidoRepository;

@Service
public class PedidoPutV1Service implements PedidoPutService {
    @Autowired
    PedidoRepository pedidoRepository;

    @Autowired
    ClienteRepository clienteRepository;
    
    @Autowired
    PedidoPrecoService pedidoPrecoService;

    @Autowired
    ModelMapper modelMapper;

    @Override
    public Pedido put(Long pedidoId, String cliCodAcesso, PedidoPostPutRequestDTO pedidoPostPutRequestDTO) {
        if (pedidoId == null || cliCodAcesso == null){
            throw new CommerceException();
        }
        // if (!pedidoRepository.existsById(pedidoId)) {
        //     throw new PedidoInexistenteException();
        // }
        //Pedido pedido = pedidoRepository.findById(pedidoId).get();
        Pedido pedido = pedidoRepository.findById(pedidoId).orElseThrow(PedidoInexistenteException::new);
        Cliente cliente = clienteRepository.findById(pedidoPostPutRequestDTO.getClienteId()).orElseThrow(ClienteInexistenteException::new);
         if (cliCodAcesso.equals(cliente.getCodigoAcesso())) {
            pedido.setPreco(pedidoPrecoService.calcPreco(pedidoPostPutRequestDTO));
            pedido.setEnderecoEntrega(pedidoPostPutRequestDTO.getEnderecoEntrega());
            pedido.setEstabelecimentoId(pedidoPostPutRequestDTO.getEstabelecimentoId());
            pedido.setClienteId(pedidoPostPutRequestDTO.getClienteId());
            pedido.setEntregadorId(pedidoPostPutRequestDTO.getEntregadorId());
            pedido.setPizzas(pedidoPostPutRequestDTO.getPizzas());
            pedido.setStatusEntrega(pedidoPostPutRequestDTO.getStatusEntrega());
            pedido.setMeioPagamento(pedidoPostPutRequestDTO.getMeioPagamento());
            pedido.setStatusPagamento(pedidoPostPutRequestDTO.isStatusPagamento());
            return pedidoRepository.save(pedido);
         } else {
            throw new CodigoInvalidoException();
         }
    }
}

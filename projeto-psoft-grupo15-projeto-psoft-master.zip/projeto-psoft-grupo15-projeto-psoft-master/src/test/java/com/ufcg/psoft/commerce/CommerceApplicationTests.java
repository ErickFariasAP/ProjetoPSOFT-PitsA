package com.ufcg.psoft.commerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class CommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
